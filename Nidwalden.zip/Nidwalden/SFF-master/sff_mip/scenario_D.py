# -*- coding: utf-8 -*-
"""
Created on Tue May 24 13:52:31 2022

@author: Luc
"""

#Plotting experimentation with results.h5


# External modules

from matplotlib import pyplot as plt
from matplotlib.pyplot import figure
import numpy as np
import os.path
import pandas as pd
import time
import os
# Internal modules
# from read_inputs import (Periods, dt_end, Days, Hours, Ext_T, Irradiance, 
#                          Build_cons, Build_T, AD_T, Fueling, Frequence, P)
# from global_set import (Units, Units_storage, Resources, Color_code, 
#                         Linestyle_code, Linestyles, Abbrev, Unit_color, 
#                         G_res, U_prod, U_cons)
import results
from data import get_hdf, get_all_param
import data


#result_path = ''   #
    
df = get_hdf( 'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\Nidwalden\\SFF-master\\sff_mip\\results\\2022-07-22\\run_nbr_4\\results.h5','daily')

    #'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\Nidwalden\\SFF-master\\sff_mip\\results\\Scenario_B\\Report\\run_nbr_2_totex\\results.h5','daily')    

    #'C:\\Users\\Luc\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\Scenario_B\\results.h5','daily')
    
    #'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\2022-05-31\\run_nbr_1\\results.h5') #, 'single')

    # amors check for opex and capex: 'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Robinson_E_S_O\\Robinson_E_S_O\\sff_mip\\results\\2022-04-07\\run_nbr_1\\results.h5')
        
    #'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\2022-05-05\\run_nbr_3\\results.h5')
    
gasboiler_heat_prod = df['unit_prod[GBOI][Heat]']
elec_grid_import = df['grid_import[Elec]']
gas_grid_import = df['grid_import[Gas]']
gasboiler_gas_cons = df['unit_cons[GBOI][Gas]']    


def Nid_plot_hourly1(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Boiler Heat Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Heat Production [kWh] ')
        plt.show()
Nid_plot_hourly1(True,gasboiler_heat_prod)

def Nid_plot_hourly2(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Electricity Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity [kWh] ')
        plt.show()
Nid_plot_hourly2(True,elec_grid_import)




def Nid_plot_hourly4(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Goiler Gas Consumption Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly4(True,gasboiler_gas_cons)



GADUPT_heat_prod = df['unit_prod[GADUPT][Gas]']
def Nid_plot_hourly5(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('GADUP2 Gas Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly5(True,GADUPT_heat_prod)



MADUPT_heat_prod = df['unit_prod[MADUPT][Gas]']
def Nid_plot_hourly6(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('MADUP2 Gas Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly6(True,MADUPT_heat_prod)

SADUPT_heat_prod = df['unit_prod[SADUPT][Gas]']
def Nid_plot_hourly7(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('SADUP2 Gas Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly7(True,SADUPT_heat_prod)


WGEMT_heat_prod = df['unit_prod[WGEMT][Gas]']
def Nid_plot_hourly8(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('WGEM2 Gas Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly8(True,WGEMT_heat_prod)


Heat_Unused = df['unused[Gas]']
def Nid_plot_Heat_unused(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Heat Production Unused Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Heat [kWh] ')
        plt.show()
Nid_plot_Heat_unused(True,Heat_Unused)


#Total_gas = sum(WGMT_heat_prod) + sum(MADUP_heat_prod) + sum(GADUP_heat_prod) + sum(SADUP_heat_prod) + sum(gas_grid_import)
Total_gas_biomass = sum(WGEMT_heat_prod) + sum(MADUPT_heat_prod) + sum(GADUPT_heat_prod) + sum(SADUPT_heat_prod)
Total_gas_biomass_profile = (WGEMT_heat_prod) + (MADUPT_heat_prod) + (GADUPT_heat_prod) + (SADUPT_heat_prod)
LHV_CH4 = 13.9 #kWh/kg
Total_kg_CO2_profile = (WGEMT_heat_prod)/LHV_CH4*5/4 + (MADUPT_heat_prod)/13.9*0.4/0.6  + (GADUPT_heat_prod)/13.9*0.45/0.55 
efficiency_adding_H2 = 0.84 
Total_kg_H2_profile = Total_kg_CO2_profile/44.01*2.01*4/efficiency_adding_H2
Total_kg_H2 = sum(Total_kg_H2_profile)
Total_kg_CH4_profile = Total_kg_CO2_profile/44.01*16.04
Total_kg_CH4 = sum(Total_kg_CH4_profile)
efficiency_electrolyzer = 0.69 #cite van report amor, kan ook naar rothrist kijken


LHV_H2 = 33.3 #kWh/kg
HHV_H2 = 39.4 #kWh/kg hydrogen engineering toolbox
HHV_CH4 = 15.4 #kWh/kg
Elec_needed_forH2 = Total_kg_H2*LHV_H2/efficiency_electrolyzer
LHV_CH4_end = Total_kg_CH4 * LHV_CH4
efficiency_extra_process = LHV_CH4_end/Elec_needed_forH2


Methane_prod = {}
Methane_production_file = data.open_csv('Methane_extra_production.txt', 'profiles', '\t') #, separator)
Methane_prod['Gas'] = Methane_production_file.squeeze()


PV_prod = {}
PV_production_file = data.open_csv('PV_production_total.txt', 'profiles', '\t') #, separator)
PV_prod['Elec'] = PV_production_file.squeeze()


#check = pd.read_csv(r'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\Nidwalden\\SFF-master\\sff_mip\\inputs\\profiles\\PV_production_total.txt', delimiter = "\t")
#series = check.squeeze()
elec_check = elec_grid_import.values - PV_prod['Elec'].values


import_pos = []
export_neg = []
for i in range(0,len(elec_check)):
    if (elec_check[i] >= 0 ):
        import_pos.append(elec_check[i])
        export_neg.append(0)
    else:
        import_pos.append(0)
        export_neg.append(elec_check[i])




def Nid_plot_hourly9(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Electricity Import Nidwalden ')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity [kWh] ')
        plt.show()
Nid_plot_hourly9(True,import_pos)


def Nid_plot_hourly10(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Electricity Export Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity [kWh] ')
        plt.show()
Nid_plot_hourly10(True,[abs(number) for number in export_neg])




WGEMT_heat_prod = df['unit_prod[WGEMT][Heat]']
def Nid_plot_hourly11(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('WGEM2 Gas Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Heat [kWh] ')
        plt.show()
Nid_plot_hourly11(True,WGEMT_heat_prod)







gas_check = gas_grid_import.values-Methane_prod['Gas'].values

def Nid_plot_hourly3(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly3(True,gas_check)

def Nid_plot_hourly12(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly12(True,gas_grid_import.values)


def Nid_plot_hourly13(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly13(True,Methane_prod['Gas'].values)


#gas_export = sum(gas_grid_import-(np.ones(8760)*LHV_CH4_end/8760))
check_jan = gas_check[0:31*24]
check_feb = gas_check[31*24:31*24+28*24] 











'''


gasboiler_heat_prod = df['unit_prod[GBOI][Heat]']
elec_grid_import = df['grid_import[Elec]']
gas_grid_import = df['grid_import[Gas]']
gasboiler_gas_cons = df['unit_cons[GBOI][Gas]']


#battery_cons = df['unit_cons[BAT][Elec]']
#battery_prod = df['unit_prod[BAT][Elec]']


#WGMO_prod = df['unit_prod[WGMO][Gas]']
#WGMO_cons = df['unit_cons[WGMO][WO]']

#WGMT_prod = df['unit_prod[WGMT][Gas]']
#WGMT_cons = df['unit_cons[WGMT][WO]']


SADICE_prod_e = df['unit_prod[SADICE][Elec]']
SADICE_prod_t = df['unit_prod[SADICE][Heat]']
SADICE_cons   = df['unit_cons[SADICE][SS]']

MADICE_prod_e = df['unit_prod[MADICE][Elec]']
MADICE_prod_t = df['unit_prod[MADICE][Heat]']
MADICE_cons   = df['unit_cons[MADICE][AM]']

WCHP_prod_e = df['unit_prod[WCHP][Elec]']
WCHP_prod_t = df['unit_prod[WCHP][Heat]']
WCHP_cons   = df['unit_cons[WCHP][WO]']

WGICE_prod_e = df['unit_prod[WGICE][Elec]']
WGICE_prod_t = df['unit_prod[WGICE][Heat]']
WGICE_cons   = df['unit_cons[WGICE][WO]']

'''





'''
    n = 'Capex'
    C_meta[n] = ['Unit CAPEX relative to unit size and cost parameters', 78]
    m.addConstrs((unit_capex[u] == P[u,'Cost_multiplier']*
                  (unit_size[u]*P[u,'Cost_per_size'] + 
                   unit_install[u]*P[u,'Cost_per_unit'])*
                  annualize(P[u,'Life'], P['Farm','i'])*1e-3
                  for u in Units), n);
'''




'''

def Electricity_grid_plot(Plot):
    if Plot:
        time        = np.arange(0, 24, 1);    
        day = np.arange(0,365,1);
        fig = plt.figure()
        ax = plt.axes(projection='3d')
        
        X, Y = np.meshgrid(time,day)
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('Hour of the day')
        ax.set_ylabel('Day of the year ')
        ax.set_zlabel('Electricity use [kWh] ')
        ax.plot_surface(X, Y, np.reshape(elec_grid_import.to_numpy(),(365,24))  )
        plt.title('Electricity use Nidwalden')
        plt.show()


#Electricity_grid_plot(True)




def Gasgrid_plot(Plot):
    if Plot:
        time        = np.arange(0, 24, 1);    
        day = np.arange(0,365,1);
        fig = plt.figure()
        ax = plt.axes(projection='3d')
        
        X, Y = np.meshgrid(time,day)
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('Hour of the day')
        ax.set_ylabel('Day of the year ')
        ax.set_zlabel('Gas use [kWh] ')
        ax.plot_surface(X, Y, np.reshape(gas_grid_import.to_numpy(),(365,24))  )
        plt.title('Gas use Nidwalden')
        plt.show()

#Gasgrid_plot(True)


def Nid_plot_daily(Plot):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Electricity_use_daily   = np.reshape(elec_grid_import.to_numpy(),(365,24)).sum(axis=1)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Daily Electricity use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Electricity use [kWh] ')
        plt.show()

def Nid_plot_daily_gas(Plot):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Gas_use_daily   = np.reshape(gas_grid_import.to_numpy(),(365,24)).sum(axis=1)
        plt.plot(time,Nid_Gas_use_daily) #, linewidth=10)
        plt.title('Daily Gas use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Gas use [kWh] ')
        plt.show()

#Nid_plot_daily(True)
#Nid_plot_daily_gas(True)
 

'''

'''


def Nid_plot_daily(Plot, path,cd):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Electricity_use_daily   = Nid_cons['Elec'].sum(axis=1)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Daily Electricity use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Electricity use [kWh] ')
        

def Nid_plot_hourly(Plot, path,cd):
    if Plot:
        time        = np.arange(0, 8760, 1);
        Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Hourly Electricity use Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity use [kWh] ')

'''



'''
time        = np.arange(0, 240, 1);
#Nid_Electricity_use_daily   = Nid_cons['Elec'].sum(axis=1)
plt.plot(time,gasboiler_heat_prod) #, linewidth=10)
plt.title('Hourly gas boiler heat production for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas heat production [kWh] ')
plt.show()

plt.plot(time,gasboiler_gas_cons) #, linewidth=10)
plt.title('Hourly gas boiler gas consumption for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas consumption [kWh] ')
plt.show()

plt.plot(time,elec_grid_import) #, linewidth=10)
plt.title('Hourly electricity grid import for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Electricity [kWh] ')
plt.show()

plt.plot(time,gas_grid_import) #, linewidth=10)
plt.title('Hourly gas grid import for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas [kWh] ')
plt.show()

'''





