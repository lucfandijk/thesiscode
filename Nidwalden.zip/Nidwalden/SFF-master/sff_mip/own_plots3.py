# -*- coding: utf-8 -*-
"""
Created on Tue May 24 13:52:31 2022

@author: Luc
"""

#Plotting experimentation with results.h5


# External modules

from matplotlib import pyplot as plt
from matplotlib.pyplot import figure
import numpy as np
import os.path
import pandas as pd
import time
import os
# Internal modules
# from read_inputs import (Periods, dt_end, Days, Hours, Ext_T, Irradiance, 
#                          Build_cons, Build_T, AD_T, Fueling, Frequence, P)
# from global_set import (Units, Units_storage, Resources, Color_code, 
#                         Linestyle_code, Linestyles, Abbrev, Unit_color, 
#                         G_res, U_prod, U_cons)
import results
from data import get_hdf, get_all_param



check = get_hdf( 'C:\\Users\\Luc\Documents\\WB\\Master\\Graduation\\Files\\Model\\Nidwalden\\SFF-master\\sff_mip\\results\\Scenario_C\\Report\\run_nbr_1_totex\\results.h5')
    
df = get_hdf( 'C:\\Users\\Luc\Documents\\WB\\Master\\Graduation\\Files\\Model\\Nidwalden\\SFF-master\\sff_mip\\results\\Scenario_C\\Report\\run_nbr_1_totex\\results.h5','daily')
    
    #'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\2022-05-31\\run_nbr_1\\results.h5') #, 'single')

    # amors check for opex and capex: 'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Robinson_E_S_O\\Robinson_E_S_O\\sff_mip\\results\\2022-04-07\\run_nbr_1\\results.h5')
        
    #'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\2022-05-05\\run_nbr_3\\results.h5')
    
gasboiler_heat_prod = df['unit_prod[GBOI][Heat]']
elec_grid_import = df['grid_import[Elec]']
gas_grid_import = df['grid_import[Gas]']
gasboiler_gas_cons = df['unit_cons[GBOI][Gas]']    


def Nid_plot_hourly1(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Boiler Heat Production Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Heat Production [kWh] ')
        plt.show()
Nid_plot_hourly1(True,gasboiler_heat_prod)

def Nid_plot_hourly2(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Electricity Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity [kWh] ')
        plt.show()
Nid_plot_hourly2(True,elec_grid_import)


def Nid_plot_hourly3(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Import Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly3(True,gas_grid_import)

def Nid_plot_hourly4(Plot,xplot):
    if Plot:
        time        = np.arange(0, 8760, 1);
        #Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,xplot) #, linewidth=10)
        plt.title('Gas Goiler Gas Consumption Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Gas [kWh] ')
        plt.show()
Nid_plot_hourly4(True,gasboiler_gas_cons)





'''


gasboiler_heat_prod = df['unit_prod[GBOI][Heat]']
elec_grid_import = df['grid_import[Elec]']
gas_grid_import = df['grid_import[Gas]']
gasboiler_gas_cons = df['unit_cons[GBOI][Gas]']


#battery_cons = df['unit_cons[BAT][Elec]']
#battery_prod = df['unit_prod[BAT][Elec]']


#WGMO_prod = df['unit_prod[WGMO][Gas]']
#WGMO_cons = df['unit_cons[WGMO][WO]']

#WGMT_prod = df['unit_prod[WGMT][Gas]']
#WGMT_cons = df['unit_cons[WGMT][WO]']


SADICE_prod_e = df['unit_prod[SADICE][Elec]']
SADICE_prod_t = df['unit_prod[SADICE][Heat]']
SADICE_cons   = df['unit_cons[SADICE][SS]']

MADICE_prod_e = df['unit_prod[MADICE][Elec]']
MADICE_prod_t = df['unit_prod[MADICE][Heat]']
MADICE_cons   = df['unit_cons[MADICE][AM]']

WCHP_prod_e = df['unit_prod[WCHP][Elec]']
WCHP_prod_t = df['unit_prod[WCHP][Heat]']
WCHP_cons   = df['unit_cons[WCHP][WO]']

WGICE_prod_e = df['unit_prod[WGICE][Elec]']
WGICE_prod_t = df['unit_prod[WGICE][Heat]']
WGICE_cons   = df['unit_cons[WGICE][WO]']

'''





'''
    n = 'Capex'
    C_meta[n] = ['Unit CAPEX relative to unit size and cost parameters', 78]
    m.addConstrs((unit_capex[u] == P[u,'Cost_multiplier']*
                  (unit_size[u]*P[u,'Cost_per_size'] + 
                   unit_install[u]*P[u,'Cost_per_unit'])*
                  annualize(P[u,'Life'], P['Farm','i'])*1e-3
                  for u in Units), n);
'''




'''

def Electricity_grid_plot(Plot):
    if Plot:
        time        = np.arange(0, 24, 1);    
        day = np.arange(0,365,1);
        fig = plt.figure()
        ax = plt.axes(projection='3d')
        
        X, Y = np.meshgrid(time,day)
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('Hour of the day')
        ax.set_ylabel('Day of the year ')
        ax.set_zlabel('Electricity use [kWh] ')
        ax.plot_surface(X, Y, np.reshape(elec_grid_import.to_numpy(),(365,24))  )
        plt.title('Electricity use Nidwalden')
        plt.show()


#Electricity_grid_plot(True)




def Gasgrid_plot(Plot):
    if Plot:
        time        = np.arange(0, 24, 1);    
        day = np.arange(0,365,1);
        fig = plt.figure()
        ax = plt.axes(projection='3d')
        
        X, Y = np.meshgrid(time,day)
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('Hour of the day')
        ax.set_ylabel('Day of the year ')
        ax.set_zlabel('Gas use [kWh] ')
        ax.plot_surface(X, Y, np.reshape(gas_grid_import.to_numpy(),(365,24))  )
        plt.title('Gas use Nidwalden')
        plt.show()

#Gasgrid_plot(True)


def Nid_plot_daily(Plot):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Electricity_use_daily   = np.reshape(elec_grid_import.to_numpy(),(365,24)).sum(axis=1)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Daily Electricity use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Electricity use [kWh] ')
        plt.show()

def Nid_plot_daily_gas(Plot):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Gas_use_daily   = np.reshape(gas_grid_import.to_numpy(),(365,24)).sum(axis=1)
        plt.plot(time,Nid_Gas_use_daily) #, linewidth=10)
        plt.title('Daily Gas use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Gas use [kWh] ')
        plt.show()

#Nid_plot_daily(True)
#Nid_plot_daily_gas(True)
 

'''

'''


def Nid_plot_daily(Plot, path,cd):
    if Plot:
        time        = np.arange(0, 365, 1);
        Nid_Electricity_use_daily   = Nid_cons['Elec'].sum(axis=1)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Daily Electricity use Nidwalden')
        plt.xlabel('Hour of the day')
        plt.ylabel('Electricity use [kWh] ')
        

def Nid_plot_hourly(Plot, path,cd):
    if Plot:
        time        = np.arange(0, 8760, 1);
        Nid_Electricity_use_daily   = np.reshape(Nid_cons['Elec'],8760)
        plt.plot(time,Nid_Electricity_use_daily) #, linewidth=10)
        plt.title('Hourly Electricity use Nidwalden')
        plt.xlabel('Hour ')
        plt.ylabel('Electricity use [kWh] ')

'''



'''
time        = np.arange(0, 240, 1);
#Nid_Electricity_use_daily   = Nid_cons['Elec'].sum(axis=1)
plt.plot(time,gasboiler_heat_prod) #, linewidth=10)
plt.title('Hourly gas boiler heat production for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas heat production [kWh] ')
plt.show()

plt.plot(time,gasboiler_gas_cons) #, linewidth=10)
plt.title('Hourly gas boiler gas consumption for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas consumption [kWh] ')
plt.show()

plt.plot(time,elec_grid_import) #, linewidth=10)
plt.title('Hourly electricity grid import for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Electricity [kWh] ')
plt.show()

plt.plot(time,gas_grid_import) #, linewidth=10)
plt.title('Hourly gas grid import for 10 clustered days')
plt.xlabel('Hour')
plt.ylabel('Gas [kWh] ')
plt.show()

'''





