# -*- coding: utf-8 -*-
"""
Created on Tue May 24 13:52:31 2022

@author: Luc
"""

#Plotting experimentation with results.h5

# External modules

from matplotlib import pyplot as plt
from matplotlib.pyplot import figure
import numpy as np
import os.path
import pandas as pd
import time
import os
# Internal modules
#from read_inputs import (Periods, dt_end, Days, Hours, Ext_T, Irradiance, 
#                         Build_cons, Build_T, AD_T, Fueling, Frequence, P)
from global_set import (Units, Units_storage, Resources, Color_code, 
                        Linestyle_code, Linestyles, Abbrev, Unit_color, 
                        G_res, U_prod, U_cons)
import results
from data import get_hdf, get_all_param, get_param, annualize


P, P_meta = get_param('cost_param.csv')
P['Farm','i'] = 0.025
#Farm,i,0.025,-,Annual interest rate,Nils PdS,,i,Annual interest rate,0.1,


path_input = 'C:\\Users\\Luc\\Documents\\WB\\Master\\Graduation\\Files\\Model\\archief\\Original_files_Nils\\SFF-master\\sff_mip\\results\\2022-06-08\\run_nbr_1\\results.h5'


def plot_value(axis, x_position, value):
    if np.round(value) > 0:
        ysize = axis.get_ylim()[1] - axis.get_ylim()[0]
        axis.text(x_position, value + ysize*0.05, '{:.0f}'.format(value))

#Var_check = {}

Names_total = []
Values_total = []
Totale_test = []

def unit_size(path):
    """ Plot a bar chart of the installed capacity of each unit given a path to
        the hdf result file.
    """
    # Split into torage and non storage units
    Names, Values = {}, {}
    Units_ns = list(set(Units) - set(Units_storage))
    Units_ns.sort()
    Names['non_storage'] = [f'unit_size[{u}]' for u in Units_ns]
    Names['storage'] = [f'unit_size[{u}]' for u in Units_storage]
    
    
    #print(Names)
    
    #Var_check = (Names)
    # Only time independent results are used, set names as index
    df = get_hdf(path, 'single')
    df.set_index('Var_name', inplace=True)
    for t in ['non_storage', 'storage']:
        Values[t] = [df.loc[n, 'Value'] for n in Names[t]]   
        
    #    print(Values)
    
    # Figure options
    fig, ax1 = plt.subplots()
    plt.title('Installed capacity for each unit')
    fig.set_size_inches(15, 5)                          #(8, 3)
    #fig.set_size_inches(8, 3)
    ax2 = ax1.twinx()
    ax1.set_ylabel('Production capacity in kW')
    ax2.set_ylabel('Storage capacity in kWh')
    ax1.set_xlim(-1, len(Units))
    ax1.set_ylim(0, max(Values['non_storage'])*1.25)
    ax2.set_ylim(0, max(Values['storage'])*1.25)
    
    
    
    
#    Names_total = []
#    Values_total = []
    i = 0
    for n in Names['non_storage']:
        ax1.bar(i, df.loc[n, 'Value'], color='darkgrey')
        plot_value(ax1, i - 0.25, df.loc[n, 'Value'])
        #print(df.loc[n, 'Value'])
        Name = Names['non_storage'][i]
        Names_total.append(Name)
        Value = df.loc[n, 'Value']
        Values_total.append(Value)
        Totale_test.append(Name)
        Totale_test.append(Value)
        i += 1

    print(Names_total)
    print(Values_total)


    # for n in Names['storage']:
    #     ax2.bar(i, df.loc[n, 'Value'], color='lightgrey')
    #     plot_value(ax2, i - 0.25, df.loc[n, 'Value'])
    #     print(df.loc[n, 'Value'])
    #     i += 1
                
    #print(Names['non_storage'])
        
    # Store the figure in aplt object accessible anywhere
    Names_order = Units_ns + list(Units_storage)
    plt.xticks(range(len(Units)), 
               [Abbrev[Names_order[i]] for i in range(len(Units))])
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.show()
    return Names_total, Values_total
    

unit_size(path_input)    

print(Names_total)
print(Values_total)

Totale_ding = np.reshape(np.append(Names_total,Values_total),(25,2))
Totale_dingetje = np.reshape(Totale_test,(25,2))



def unit_capex(capex_hand):
    """ Return a dictionnary containing the capex of each unit for a given
        series of single results. 
    """
    from data import annualize
    from read_inputs import P
    i = P['Farm', 'i']
    capex = {}
    for u in Units:
        capex = capex_hand/annualize(P[u, 'Life'], i)
    return capex




'''
n = 'Capex'
C_meta[n] = ['Unit CAPEX relative to unit size and cost parameters', 78]
m.addConstrs((unit_capex[u] == P[u,'Cost_multiplier']*
              (unit_size[u]*P[u,'Cost_per_size'] + 
               unit_install[u]*P[u,'Cost_per_unit'])*
              annualize(P[u,'Life'], P['Farm','i'])*1e-3
              for u in Units), n);

n = 'capex_sum'
C_meta[n] = ['Sum of the CAPEX of all units', 79]
m.addConstr(capex == sum(unit_capex[u] for u in Units), n);

n = 'opex_sum'
C_meta[n] = ['Sum of the OPEX of all resources', 80]
m.addConstr(opex == sum(grid_import_a[r]*P[r,'Import_cost'] - 
                        grid_export_a[r]*P[r,'Export_cost'] 
                        for r in G_res)/1000 
                    + sum(unit_capex[u]*P[u,'Maintenance']/
                          annualize(P[u,'Life'], P['Farm','i'])
                          for u in Units), n);

n = 'totex_sum'
C_meta[n] = ['TOTEX relative to the OPEX, the annual CAPEX', 81]
m.addConstr(totex == opex + capex, n);


'''



