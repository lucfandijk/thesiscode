"""
### Declare global sets of units and resources - They are immutable (tuples) or treated as such
    #   Abbrev      dict of abbreviations
    #   Units       tuple of all units in the list units
    #   Resources   tuple of resources
    #   U_prod      dict of resource each unit produce
    #   U_cons      dict of resource each unit consume 
    #   U_res       dict of units producing and consuming each resource
    #   U_storage   tuple of storage units
    #   Heat_cons   tuple of units and buildings consuming heat
    #   Heat_prod   tuple of units producing heat
    #   G_res       tuple of resources exchanged by the grid
    #   Color_code      dict of colors, one for each resource
    #   Linestyle_code  dict of linestyle names, on for each unit building and grid
    #   Linestyles      dict relating linestyle names to linestyles
"""

# Abbreviations
Abbrev = {'GBOI':   'Gas Boiler',
          'WBOI':   'Wood Boiler', 
          'EH':     'Electric Heater',
          'AHP':    'Air-Air Heat Pump',
          'GHP':    'Geothermal Heat Pump',
          'PV':     'Photovoltaic Panels', 
          'BAT':    'Battery',
          'GCSOFC': 'Gas Cleaning for SOFC',
          'SOFC':   'Solid Oxide Fuel cell',
          'ICE':    'Internal Combustion Engine',
          'AD':     'Anaerobic Digester',
          'CGT':    'Compressed Gas Tank',
          'BS':     'Biogas Storage',
          'BU':     'Biogas Upgrading',
          'GI':     'Grid Injection',
          'GFS':    'Gas Fueling Station',
          'build':  'building',
          'Elec':   'Electricity',
          'Gas':    'Natural Gas or Syntetic NG',
          'Biogas': '60% CH4, 40% CO2',
          'Heat':   'Heat',
          'BM':     'Bio-methane',
          'WO':     'Wood',
          'AM':     'Animal Manure',
          'GW':     'Green Waste',
          'SS':     'Sewage Sludge',
          'Nid':    'Nidwalden',
          
          #Scenario B
          'WGMO':   'Wood Gasification Methanation 1',
          'WGMT':   'Wood Gasification Methanation 2',
          'MHYGU':  'Hygas-Upgrading for Manure',
          'GHYGU':  'Hygas-Upgrading for Green Waste',
          'MADUP':  'Anaerobic Digestion and Upgrading for Manure',
          'GADUP':  'Anaerobic Digestion and Upgrading for Green Waste',
          'SHYGU':  'Hygas-Upgrading for Sewage Sludge',
          'SADUP':  'Anaerobic Digestion and Upgrading for Sewage Sludge',

          #Scenario C
          'WGICE':  'Wood Gasification and ICE ',   
          'WCHP':   'Wood Combined Heat and Power',   
          'MADICE': 'Anaerobic Digestion and ICE for Manure',          
          'SADICE': 'Anaerobic Digestion and ICE for Sewage Sludge', 
                
          #Scenario D
          'WGEMO':  'Wood Gasification Electrolysis Methanation 1',
          'WGEMT':  'Wood Gasification Electrolysis Methanation 2',          
          'MADUPO': 'Anaerobic Digestion and Upgrading for Manure 1',
          'MADUPT': 'Anaerobic Digestion and Upgrading for Manure 2',
          'GADUPO': 'Anaerobic Digestion and Upgrading for Green Waste 1',
          'GADUPT': 'Anaerobic Digestion and Upgrading for Green Waste 2',  
          'SADUPO': 'Anaerobic Digestion and Upgrading for Sewage Sludge 1',
          'SADUPT': 'Anaerobic Digestion and Upgrading for Sewage Sludge 2',
          
          }

# Energy conversion units
Units = ('GBOI', 'WBOI', 'EH', 'AHP', 'GHP',    # Heating
         'SOFC', 'ICE',                         # Cogeneration
         'AD', 'PV',                            # Energy Production
         'GCSOFC', 'GFS', 'BU', 'GI',           # Utility
         'BAT', 'CGT', 'BS',                    # Energy Storage
       #  'WGMO', 'WGMT', 'MHYGU', 'GHYGU', 'MADUP', 'GADUP', 'SHYGU', 'SADUP',   #Scenario B
       #  'WGICE', 'WCHP', 'MADICE', 'SADICE',                                    #Scenario C
         'WGEMO', 'WGEMT', 'MADUPO', 'MADUPT', 'GADUPO', 'GADUPT',  'SADUPO', 'SADUPT',   #Scenario D
         
         )

# Resources and energy carriers
Resources = ('Elec', 'Gas', 'Wood', 'Biogas', 'BM', 'Biomass', 'Heat', 'Diesel', 'WO', 'AM', 'GW', 'SS', ) 



###################################################
# PAS OP: OOK NOG HEAT PROD AND ELEC CONS TOEVOEGEN BIJ BIOMETHANE TECHNOLOGIES LATER
###################################################




# The resources each unit produce
U_prod = {
    'GBOI':     ('Heat',),
    'WBOI':     ('Heat',),
    'EH':       ('Heat',),
    'AHP':      ('Heat',),
    'GHP':      ('Heat',),
    'PV':       ('Elec',),
    'BAT':      ('Elec',),
    'GCSOFC':   ('Biogas', 'BM'),
    'SOFC':     ('Elec', 'Heat'),
    'ICE':      ('Elec', 'Heat'),
    'AD':       ('Biogas',),
    'CGT':      ('BM',),
    'BS':       ('Biogas',),
    'BU':       ('BM',),
    'GI':       ('BM',),
    'GFS':      ('BM', 'Gas'),
    

    #Scenario D
    'WGEMO':    ('Gas','Heat'),
    'WGEMT':    ('Gas','Heat'),        
    'MADUPO':   ('Gas','Heat'),
    'MADUPT':   ('Gas','Heat'),
    'GADUPO':   ('Gas','Heat'),
    'GADUPT':   ('Gas','Heat'),
    'SADUPO':   ('Gas','Heat'),
    'SADUPT':   ('Gas','Heat'),


    }

'''

    #Scenario B
    'WGMO':     ('Gas','Heat'),
    'WGMT':     ('Gas','Heat'),
    'MHYGU':    ('Gas',),
    'GHYGU':    ('Gas',),
    'MADUP':    ('Gas',),
    'GADUP':    ('Gas',),
    'SHYGU':    ('Gas',),
    'SADUP':    ('Gas',),


    
    #Scenario C
    'WGICE':    ('Elec', 'Heat'),
    'WCHP':     ('Elec', 'Heat'),
    'MADICE':   ('Elec', 'Heat'),       
    'SADICE':   ('Elec', 'Heat'), 

 
      
  
    
          

'''    
    
    

    

# The resources each unit consumes
U_cons = {
    'GBOI':     ('Gas', 'Biogas', 'BM'),
    'WBOI':     ('Wood',),
    'EH':       ('Elec',),
    'AHP':      ('Elec',),
    'GHP':      ('Elec',),
    'BAT':      ('Elec',),
    'GCSOFC':   ('Elec', 'Biogas', 'BM'),
    'SOFC':     ('Gas', 'Biogas', 'BM'),
    'ICE':      ('Gas', 'Biogas', 'BM'),
    'AD':       ('Biomass', 'Elec', 'Heat'),
    'CGT':      ('BM', 'Elec'),
    'BS':       ('Biogas', 'Elec'),
    'BU':       ('Biogas', 'Elec'),
    'GI':       ('BM',),
    'GFS':      ('BM', 'Gas', 'Elec'),




    #Scenario D
    'WGEMO':    ('WO','Elec'),
    'WGEMT':    ('WO','Elec'),        
    'MADUPO':   ('AM','Elec'),
    'MADUPT':   ('AM','Elec'),
    'GADUPO':   ('GW','Elec'),
    'GADUPT':   ('GW','Elec'),
    'SADUPO':   ('SS','Elec'),
    'SADUPT':   ('SS','Elec'),

    
    }

''' 
    #Scenario B
    'WGMO':     ('WO','Elec'),
    'WGMT':     ('WO','Elec'),
    'MHYGU':    ('AM',),
    'GHYGU':    ('GW',),
    'MADUP':    ('AM',),
    'GADUP':    ('GW',),
    'SHYGU':    ('SS',),
    'SADUP':    ('SS',),       

    #Scenario C
    'WGICE':    ('WO',),
    'WCHP':     ('WO',),
    'MADICE':   ('AM',),    
    'SADICE':   ('SS',),

          

'''
    
    

# The units producing and consuming a given resource
# Dictionnary format: U_res['prod']['Elec'] = ['PV', 'BAT', 'SOFC']
U_res = {'prod': {}, 'cons': {}}
for r in Resources:
    for u in U_prod:
        U_res['prod'][r] = tuple(u for u in U_prod if r in U_prod[u])
    for u in U_cons:
        U_res['cons'][r] = tuple(u for u in U_cons if r in U_cons[u])

# Units that store energy
Units_storage = ('BAT', 'CGT', 'BS')

# The buildings and units consuming and producing heat
Heat_cons = tuple(['build'] + list(U_res['cons']['Heat']))
Heat_prod = U_res['prod']['Heat']

# Resources that can be exchanged with the grids
G_res = ('Elec', 'Gas', 'Wood', 'Diesel', 'BM')

# Linestyles for differentiating units
Linestyles = {'loosely dotted': (0, (1, 10)),
              'loosely dashed': (0, (5, 10)),
              'dashdotted': (0, (3, 5, 1, 5)),
              'densely dashdotted': (0, (3, 1, 1, 1)),
              'densely dashdotdotted': (0, (3, 1, 1, 1, 1, 1))
              }

Linestyle_code = {'PV':     'dotted', 
                  'BAT':    'dashdot', 
                  'grid':   'solid', 
                  'SOFC':   'dashed',
                  'ICE':    'dashed',
                  'GCSOFC': 'solid',
                  'BU':     'solid',
                  'GI':     'solid',
                  'AD':     'dashdotted', 
                  'build':  'densely dashdotted', 
                  'GBOI':   'loosely dashed',
                  'WBOI':   'loosely dashed',
                  'EH':     'loosely dashed',
                  'AHP':    'loosely dashed',
                  'GHP':    'loosely dashed',
                  'CGT':    'densely dashdotdotted',
                  'BS':     'densely dashdotdotted',
                  'GFS':    'solid',
                  
                  #Scenario B
                  'WGMO':     'solid', 
                  'WGMT':     'solid', 
                  'MHYGU':    'solid', 
                  'GHYGU':    'solid', 
                  'MADUP':    'solid', 
                  'GADUP':    'solid', 
                  'SHYGU':    'solid', 
                  'SADUP':    'solid', 
              
                  #Scenario C
                  'WGICE':    'solid', 
                  'WCHP':     'solid', 
                  'MADICE':   'solid',   
                  'SADICE':   'solid', 
                        
                  #Scenario D
                  'WGEMO':    'solid', 
                  'WGEMT':    'solid',      
                  'MADUPO':   'solid', 
                  'MADUPT':   'solid', 
                  'GADUPO':   'solid', 
                  'GADUPT':   'solid', 
                  'SADUPO':   'solid', 
                  'SADUPT':   'solid',                  
                  
                  
                  
                  
                  'default':'solid'   # All added technologies will get the default
                  }

# Colors for differentiating resources
Color_code = {'Elec':       'royalblue', 
              'Biogas':     'limegreen',
              'BM':         'green',
              'Biomass':    'khaki', 
              'Gas':        'gray',
              'Wood':       'sandybrown',
              'Heat':       'firebrick', 
              'Ext_T':      'navy', 
              'Irradiance': 'red', 
              'Diesel':     'black',
              
              # Biomasses
              'WO':       'green',
              'AM':       'brown',
              'GW':       'darkgreen',
              'SS':       'sandybrown',
              
              'default':    'purple' # All added technologies will get the default
              }

# Colors to differentiate units in the pareto plots
Unit_color = {# Heating
        'GBOI':     'crimson', 
        'WBOI':     'sandybrown', 
        'EH':       'darkred', 
        'AHP':      'sandybrown', 
        'GHP':      'lightcoral',
        # Cogeneration
        'SOFC':     'yellow', 
        'ICE':      'black',
        # Energy Production                         
        'AD':       'mediumseagreen', 
        'PV':       'skyblue',
        # Utility                            
        'GCSOFC':   'moccasin', 
        'GFS':      'darkviolet', 
        'BU':       'violet', 
        'GI':       'magenta',
        # Energy Storage           
        'BAT':      'steelblue', 
        'CGT':      'blueviolet', 
        'BS':       'seagreen',
        
        
        #Scenario B
        'WGMO':     'blue',
        'WGMT':     'blue',
        'MHYGU':    'blue',
        'GHYGU':    'blue',
        'MADUP':    'blue',
        'GADUP':    'blue',
        'SHYGU':    'blue',
        'SADUP':    'blue',
    
        #Scenario C
        'WGICE':    'red',
        'WCHP':     'red',
        'MADICE':   'red',  
        'SADICE':   'red',
              
        #Scenario D
        'WGEMO':    'green',
        'WGEMT':    'green',       
        'MADUPO':   'green',
        'MADUPT':   'green',
        'GADUPO':   'green',
        'GADUPT':   'green',
        'SADUPO':   'green',
        'SADUPT':   'green',      
            
        
        }
